// Logan's Coffee Co. - Lightbox - WEDE5020 Part 3 Section 2.1
document.addEventListener('DOMContentLoaded', function(){
    // Select all images in your 3-picture grid and menu cards
    const images = document.querySelectorAll('.shop-card-light img, .card img, .gallery img, .three-pics-grid img');
    
    // Create lightbox container
    const lightbox = document.createElement('div');
    lightbox.id = 'lightbox';
    lightbox.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.85);display:none;justify-content:center;align-items:center;z-index:9999;cursor:pointer;padding:2rem;';
    document.body.appendChild(lightbox);

    images.forEach(img => {
        img.style.cursor = 'zoom-in';
        img.addEventListener('click', function(){
            lightbox.style.display = 'flex';
            lightbox.innerHTML = `<img src="${this.src}" alt="${this.alt}" style="max-width:90%;max-height:85vh;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,0.5);animation:zoomIn 0.3s;"><span style="position:absolute;top:20px;right:30px;color:white;font-size:40px;cursor:pointer;">&times;</span><p style="position:absolute;bottom:20px;color:white;background:rgba(0,0,0,0.5);padding:0.5rem 1rem;border-radius:20px;font-size:0.9rem;">${this.alt}</p>`;
        });
    });

    lightbox.addEventListener('click', function(){
        this.style.display = 'none';
    });
});