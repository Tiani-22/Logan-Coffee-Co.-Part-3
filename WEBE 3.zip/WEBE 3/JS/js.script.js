// Logan's Coffee Co. - Main JS - WEDE5020 Part 3 Section 2.1, 2.2, 4, 5
document.addEventListener('DOMContentLoaded', function(){

    // ===== 1. MODAL - Today's Special (Section 2.1 Interactive) =====
    const modal = document.getElementById('enquiryModal');
    const openBtn = document.getElementById('openModalBtn');
    const closeBtn = document.querySelector('.close-modal');
    if(openBtn && modal){
        openBtn.addEventListener('click', () => { modal.style.display='block'; });
        // Auto open modal after 2 seconds on home page for demo
        setTimeout(() => { if(modal && window.location.pathname.includes('index')) modal.style.display='block'; }, 2000);
    }
    if(closeBtn) closeBtn.addEventListener('click', () => modal.style.display='none');
    window.addEventListener('click', e => { if(e.target===modal) modal.style.display='none'; });

    // ===== 2. DYNAMIC MENU - Search & Sort (Section 2.2 Dynamic Content) =====
    const searchInput = document.getElementById('searchInput');
    const sortSelect = document.getElementById('sortSelect');
    if(searchInput){
        searchInput.addEventListener('input', function(){
            const term = this.value.toLowerCase();
            document.querySelectorAll('.card').forEach(card => {
                const text = card.textContent.toLowerCase();
                card.style.display = text.includes(term) ? 'block' : 'none';
            });
        });
    }
    if(sortSelect){
        sortSelect.addEventListener('change', function(){
            const grid = document.querySelector('.menu-grid');
            if(!grid) return;
            const cards = Array.from(grid.children);
            if(this.value==='price-low') cards.sort((a,b) => parseInt(a.textContent.match(/R(\d+)/)[1]) - parseInt(b.textContent.match(/R(\d+)/)[1]));
            if(this.value==='price-high') cards.sort((a,b) => parseInt(b.textContent.match(/R(\d+)/)[1]) - parseInt(a.textContent.match(/R(\d+)/)[1]));
            if(this.value==='name') cards.sort((a,b) => a.querySelector('h3').textContent.localeCompare(b.querySelector('h3').textContent));
            cards.forEach(c => grid.appendChild(c));
        });
    }

    // ===== 3. ACCORDION - About page (Section 2.1) =====
    document.querySelectorAll('.accordion-header').forEach(header => {
        header.addEventListener('click', function(){
            const content = this.nextElementSibling;
            content.style.display = content.style.display==='block' ? 'none' : 'block';
            this.classList.toggle('active');
        });
    });

    // ===== 4. SCROLL ANIMATION (Section 2.1 CSS+JS Animation) =====
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                entry.target.style.opacity='1';
                entry.target.style.transform='translateY(0)';
                entry.target.style.transition='all 0.6s ease';
            }
        });
    });
    document.querySelectorAll('.shop-card-light, .card').forEach(el => {
        el.style.opacity='0'; el.style.transform='translateY(20px)'; observer.observe(el);
    });

    // ===== 5. FORM VALIDATION - Enquiry (Section 4 - Form Functionality) =====
    const enquiryForm = document.getElementById('enquiryForm');
    if(enquiryForm){
        enquiryForm.addEventListener('submit', function(e){
            e.preventDefault();
            document.querySelectorAll('.error-msg').forEach(el=>el.remove());
            let valid=true;
            const name=document.getElementById('fullname') || document.getElementById('cname');
            const email=document.getElementById('email') || document.getElementById('cemail');
            const phone=document.getElementById('phone');
            const date=document.getElementById('date');

            // Character length validation
            if(name && name.value.trim().length<3){ showError(name,'Name must be at least 3 characters'); valid=false; }
            // Email format validation
            if(email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)){ showError(email,'Enter valid email'); valid=false; }
            // Phone number validation - specific type of input
            if(phone && !/^[0-9]{10}$/.test(phone.value)){ showError(phone,'Phone must be exactly 10 digits e.g. 0123456789'); valid=false; }
            // Date validation
            if(date && date.value && new Date(date.value) < new Date().setHours(0,0,0,0)){ showError(date,'Date cannot be in the past'); valid=false; }

            if(!valid) return; // Error Handling - stop if invalid

            // If valid - show cost & availability response
            const responseDiv=document.getElementById('enquiryResponse') || document.getElementById('contactResponse');
            if(responseDiv){
                responseDiv.style.display='block';
                responseDiv.innerHTML=`<h3 style="color:#4A6B5A;">Thank you ${name ? name.value : 'there'}!</h3><p>Your enquiry has been received. Estimated response: Today. We will email you at ${email ? email.value : ''}.</p><p style="color:green;">✓ Submitting via AJAX...</p>`;
            }

            // AJAX Form Submission - async, better UX
            fetch(enquiryForm.action, { method:'POST', body:new FormData(enquiryForm), headers:{'Accept':'application/json'} })
            .then(r=>{ if(responseDiv) responseDiv.innerHTML+=`<p style="color:green; font-weight:bold;">✓ Submitted via AJAX - No page reload!</p>`; enquiryForm.reset(); })
            .catch(err=>{ if(responseDiv) responseDiv.innerHTML+=`<p style="color:orange;">Validated locally. AJAX demo complete.</p>`; });
        });
    }

    function showError(input, msg){
        const d=document.createElement('div'); d.className='error-msg'; d.style.cssText='color:red; font-size:0.85em; margin-top:4px;'; d.textContent=msg;
        input.parentNode.insertBefore(d, input.nextSibling); input.style.borderColor='red'; input.style.borderWidth='2px';
    }
});